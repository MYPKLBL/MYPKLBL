export default function TournamentsPage() {
  return (
    <section className="page-wrap">
      <div className="container simple-page">
        <span className="eyebrow">Tournaments</span>
        <h1>Promote upcoming events by city, region, state, and country.</h1>
        <p>
          Showcase featured tournaments, registration links, venue details, and category-based
          event discovery with a polished tournament-first design.
        </p>
      </div>
    </section>
  )
}
